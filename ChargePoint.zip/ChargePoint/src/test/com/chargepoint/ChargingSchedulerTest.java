package test.com.chargepoint;

import main.com.chargepoint.Charger;
import main.com.chargepoint.ChargingScheduler;
import main.com.chargepoint.Truck;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class ChargingSchedulerTest {
    // not written all test cases but we need to fill the test cases different conditions
    @Test
    public void testBasicCase() {
        List<Truck> trucks = Arrays.asList(new Truck(1, 100, 20),new Truck(2, 80, 50),
                new Truck(3, 120, 60), new Truck(4, 90, 30));
        List<Charger> chargers = Arrays.asList(new Charger(1, 20),new Charger(2, 30));
        int hours = 3;
        Map<Integer, List<Integer>> schedule = ChargingScheduler.sequentialSchedule(trucks, chargers, hours);
        assertNotNull(schedule.entrySet().stream().anyMatch(s-> s.equals(1))); // Varies depending on sort
    }
    @Test
    public void testSequentialSchedule() {
        // Arrange
        List<Truck> trucks = Arrays.asList(
                new Truck(1, 100, 20),  // Needs 80 kWh
                new Truck(2, 50, 10),   // Needs 40 kWh
                new Truck(3, 80, 60),   // Needs 20 kWh
                new Truck(4, 60, 0)     // Needs 60 kWh
        );
        List<Charger> chargers = Arrays.asList(
                new Charger(1, 20), // 20 kW charger
                new Charger(2, 10)  // 10 kW charger
        );
        int hours = 5; // overnight time window
        // Act
        Map<Integer, List<Integer>> schedule = ChargingScheduler.sequentialSchedule(trucks, chargers, hours);
        // Assert
        assertNotNull(schedule);
        assertTrue(schedule.containsKey(1));
        assertTrue(schedule.containsKey(2));
        // Charger 1 should get truck 1 & 3
        assertEquals(Arrays.asList(1, 3), schedule.get(1));
        // Charger 2 should get trucks 2
        assertEquals(Arrays.asList(2), schedule.get(2));
        // Truck 4 doesn't fit in time
        assertFalse(schedule.get(1).contains(4));
        assertFalse(schedule.get(2).contains(4));
    }

    @Test
    public void testscheduleCharging() {
        // Arrange
        List<Truck> trucks = Arrays.asList(
                new Truck(1, 100, 20),  // Needs 80 kWh
                new Truck(2, 50, 10),   // Needs 40 kWh
                new Truck(3, 80, 60),   // Needs 20 kWh
                new Truck(4, 60, 0)     // Needs 60 kWh
        );
        List<Charger> chargers = Arrays.asList(
                new Charger(1, 20), // 20 kW charger
                new Charger(2, 10)  // 10 kW charger
        );
        int hours = 5; // overnight time window
        // Act
        Map<Integer, List<Integer>> schedule = ChargingScheduler.sequentialSchedule(trucks, chargers, hours);
        // Assert
        assertNotNull(schedule);
        assertTrue(schedule.containsKey(1));
        assertTrue(schedule.containsKey(2));
        // Charger 1 should get truck 1 & 3
        assertEquals(Arrays.asList(1, 3), schedule.get(1));
        // Truck 4 doesn't fit in time
        assertFalse(schedule.get(1).contains(4));
        assertFalse(schedule.get(2).contains(4));
    }
}


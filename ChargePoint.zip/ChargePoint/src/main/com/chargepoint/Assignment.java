package main.com.chargepoint;

public class Assignment {
    Truck truck;
    Charger charger;
    double time;

    public Assignment(Truck truck, Charger charger, double time) {
        this.truck = truck;
        this.charger = charger;
        this.time = time;
    }
}

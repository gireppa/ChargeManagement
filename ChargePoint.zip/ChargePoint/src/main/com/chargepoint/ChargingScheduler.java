package main.com.chargepoint;

import java.util.*;

public class ChargingScheduler {

    public static Map<Integer, List<Integer>> scheduleCharging(List<Truck> trucks, List<Charger> chargers, int totalHours) {
        Map<Integer, List<Integer>> schedule = new HashMap<>();
        for (Charger c : chargers) {
            c.availableHours = totalHours;
            schedule.put(c.chargerPlatformId, new ArrayList<>());
        }
    // Generate all valid truck-charger-time combinations
        List<Assignment> possibleAssignments = new ArrayList<>();
        for (Truck truck : trucks) {
            for (Charger charger : chargers) {
                double timeNeeded = truck.neededCharge() / charger.rate;
                if (timeNeeded <= totalHours) {
                    possibleAssignments.add(new Assignment(truck, charger, timeNeeded));
                }
            }
        }
        // Sort by time needed (shortest first) to prioritize quick full charges
        possibleAssignments.sort(Comparator.comparingDouble(a -> a.time));

        Set<Integer> assignedTrucks = new HashSet<>();

        for (Assignment a : possibleAssignments) {
            if (!assignedTrucks.contains(a.truck.getVehiclePlatformId()) && a.charger.availableHours >= a.time) {
                schedule.get(a.charger.chargerPlatformId).add(a.truck.getVehiclePlatformId());
                a.charger.availableHours -= a.time;
                assignedTrucks.add(a.truck.getVehiclePlatformId());
            }
        }
        // Print the schedule
        for (Map.Entry<Integer, List<Integer>> entry : schedule.entrySet()) {
            System.out.print(entry.getKey() + ": ");
            System.out.println(String.join(", ", entry.getValue().stream().map(String::valueOf).toArray(String[]::new)));
        }
        return schedule;
    }

    public static Map<Integer, List<Integer>> sequentialSchedule(List<Truck> trucks, List<Charger> chargers, int hours) {
        Map<Integer, List<Integer>> schedule = new HashMap<>();
        Map<Integer, Double> remainingTime = new HashMap<>();

        // Initialize schedule and remaining time
        for (Charger c : chargers) {
            schedule.put(c.chargerPlatformId, new ArrayList<>());
            remainingTime.put(c.chargerPlatformId, (double) hours);
        }
        // Process trucks in the given sequential order
        for (Truck t : trucks) {
            boolean assigned = false;
            for (Charger c : chargers) {
                double timeNeeded = t.neededCharge() / c.rate;
                if (timeNeeded <= remainingTime.get(c.chargerPlatformId)) {
                    schedule.get(c.chargerPlatformId).add(t.VehiclePlatformId);
                    remainingTime.put(c.chargerPlatformId, remainingTime.get(c.chargerPlatformId) - timeNeeded);
                    assigned = true;
                    break; // move to next truck
                }
            }
            if (!assigned) {
                // Truck cannot be charged within available time
            }
        }
        return schedule;
    }
}
package main.com.chargepoint;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ChargingSchedulerMain {
    public static void main(String[] args) {

        List<Truck> trucks = Arrays.asList(
                new Truck(1, 100, 20),  // Needs 80 kWh
                new Truck(2, 50, 10),   // Needs 40 kWh
                new Truck(3, 80, 60),   // Needs 20 kWh
                new Truck(4, 60, 0)     // Needs 60 kWh
        );
        List<Charger> chargers = Arrays.asList(
                new Charger(1, 20), // 20 kW charger
                new Charger(2, 10)  // 10 kW charger
        );
        int hours = 4;

        Map<Integer, List<Integer>> schedule = ChargingScheduler.sequentialSchedule(trucks, chargers, hours);
        // Print the Sequencical schedule
        System.out.println("Printing the Sequencical charging as priority:");
        for (Map.Entry<Integer, List<Integer>> entry : schedule.entrySet()) {
            System.out.print(entry.getKey() + ": ");
            System.out.println(String.join(", ", entry.getValue().stream().map(String::valueOf).toArray(String[]::new)));
        }
// run for shortest first
        List<Truck> trucks1 = Arrays.asList(
                new Truck(1, 100, 20),  // Needs 80 kWh
                new Truck(2, 50, 10),   // Needs 40 kWh
                new Truck(3, 80, 60),   // Needs 20 kWh
                new Truck(4, 60, 0)     // Needs 60 kWh
        );
        List<Charger> chargers1 = Arrays.asList(
                new Charger(1, 20), // 20 kW charger
                new Charger(2, 10)  // 10 kW charger
        );
        int hours1 = 5; // overnight time window

        Map<Integer, List<Integer>> schedule1 = ChargingScheduler.scheduleCharging(trucks1, chargers1, hours1);
        // Print the schedule
        System.out.println("Printing the Shortest charging first as priority:");
        for (Map.Entry<Integer, List<Integer>> entry : schedule1.entrySet()) {
            System.out.print(entry.getKey() + ": ");
            System.out.println(String.join(", ", entry.getValue().stream().map(String::valueOf).toArray(String[]::new)));
        }

    }
}
